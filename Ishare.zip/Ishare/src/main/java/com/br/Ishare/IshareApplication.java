package com.br.Ishare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IshareApplication {

	public static void main(String[] args) {
		SpringApplication.run(IshareApplication.class, args);


	}

}
