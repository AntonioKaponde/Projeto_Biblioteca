package com.br.Ishare.controller;

import com.br.Ishare.dtos.EmprestimoDto;
import com.br.Ishare.model.Emprestimo;
import com.br.Ishare.service.EmprestimoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/emprestimo")
public class EmprestimoController {
    @Autowired
    private EmprestimoService service;

    @PostMapping
    public ResponseEntity<Emprestimo> salvar_emprestimo(@RequestBody EmprestimoDto emprestimo){
        this.service.criar_emprestimo(emprestimo);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @GetMapping
    public List<Emprestimo> listarTodos_emprestimos(){
        return  this.service.listar_emprestimos();
    }

    @GetMapping("/{id_emprestimo}")
    public Emprestimo listar_emprestimoId(@PathVariable UUID id_emprestimo){
        return this.service.get_emprestimoId(id_emprestimo);
    }

    @DeleteMapping("/{id_emprestimo}")
    public void delete_emprestimo(@PathVariable UUID id_emprestimo){
        this.service.remove_emprestimo(id_emprestimo);
    }
}
