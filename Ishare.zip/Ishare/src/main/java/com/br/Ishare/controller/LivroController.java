package com.br.Ishare.controller;

import com.br.Ishare.dtos.LivroDto;
import com.br.Ishare.model.Livro;
import com.br.Ishare.service.LivroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/livro")
public class LivroController {
    @Autowired
    private LivroService service;

    @PostMapping
    public ResponseEntity<Livro> salvar_livro(@RequestBody LivroDto livroDto){
        this.service.criar_livro(livroDto);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @GetMapping
    public List<Livro> listarTodos_livro(){
        return  this.service.listar_livros();
    }

    @GetMapping("/{id_livro}")
    public Livro listar_livroId(@PathVariable UUID id_livro){
        return this.service.get_livroId(id_livro);
    }

    @DeleteMapping("/{id_livro}")
    public void delete_livro(@PathVariable UUID id_livro){
        this.service.remove_livro(id_livro);
    }

}
