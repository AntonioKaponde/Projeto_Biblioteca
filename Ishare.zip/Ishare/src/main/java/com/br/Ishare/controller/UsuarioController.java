package com.br.Ishare.controller;


import com.br.Ishare.dtos.EmprestimoDto;
import com.br.Ishare.dtos.LivroDto;
import com.br.Ishare.dtos.UsuarioDto;
import com.br.Ishare.model.Usuario;
import com.br.Ishare.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/usuario")
public class UsuarioController {
    @Autowired
    private UsuarioService service;

    @PostMapping
    public ResponseEntity<Usuario> salvar_usuario(@RequestBody UsuarioDto usuarioDto){
        this.service.criar_usuario(usuarioDto);

        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @GetMapping
    public List<Usuario> listarTodos_usuarios(){
        return  this.service.listar_usuarios();
    }

    @GetMapping("/{id_usuario}")
    public Usuario listar_usuarioId(@PathVariable UUID id_usuario){

        return this.service.get_usuarioId(id_usuario);
    }

    @DeleteMapping("/{id_livro}")
    public void delete_usuario(@PathVariable UUID id_usuario){

        this.service.remove_usuario(id_usuario);
    }

    @PostMapping("/{id_usuario}")
    public ResponseEntity<Void> salvarUsuarioEmprestimo(@PathVariable("id_usuario") String id_user, @RequestBody EmprestimoDto emprestimoDto){
        this.service.criar_usuarioEmprestimo(emprestimoDto, id_user);

        return ResponseEntity.ok().build();
    }


    @PostMapping("/{id_usuario}/{id_livro}")
    public ResponseEntity<Void> salvarUsuarioLivro(@PathVariable("id_usuario") String id_usuario, @PathVariable("id_livro") String id_livro){
        this.service.criarUsuarioLivro(id_usuario,id_livro);

        return ResponseEntity.ok().build();
    }
}
