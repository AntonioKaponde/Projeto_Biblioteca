package com.br.Ishare.dtos;

import com.br.Ishare.model.Usuario;

import java.time.LocalDate;

public record EmprestimoDto(
        LocalDate data_devolucao,
        UsuarioDto usuario
) {
}
