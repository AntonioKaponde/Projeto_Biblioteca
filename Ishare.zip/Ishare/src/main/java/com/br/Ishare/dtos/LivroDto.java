package com.br.Ishare.dtos;

import com.br.Ishare.enums.Tipo;
import com.br.Ishare.model.Emprestimo;
import com.br.Ishare.model.Usuario;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public record LivroDto(
        String titulo,
        LocalDate ano,
        List<UUID> usuarios
) {
}
