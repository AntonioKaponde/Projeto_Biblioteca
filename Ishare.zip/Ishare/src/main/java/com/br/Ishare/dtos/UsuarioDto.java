package com.br.Ishare.dtos;

import com.br.Ishare.model.Emprestimo;

import java.util.List;

public record UsuarioDto(
        String nome_usuario,
        String email_usuario,
        Integer idade_usuario,
        String morada_usuario,
        List<EmprestimoDto> emprestimoDtos
) {
}
