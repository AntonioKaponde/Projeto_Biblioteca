package com.br.Ishare.enums;

public enum Tipo {
    INFATIL,ACAO,ROMANCE,DRAMA,CIENTIFICO
}
