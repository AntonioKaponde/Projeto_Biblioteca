package com.br.Ishare.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "emprestimo")
public class Emprestimo {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id_emprestimo;
    private LocalDateTime data_emprestimo;
    private LocalDate data_devolucao;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_usuario",referencedColumnName = "id_usuario")
    @JsonBackReference
    private Usuario usuario;


    public void data_emprestimos(){
        this.data_emprestimo = LocalDateTime.now();
    }
}
