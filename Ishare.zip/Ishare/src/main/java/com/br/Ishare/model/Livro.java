package com.br.Ishare.model;

import com.br.Ishare.enums.Tipo;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.transaction.annotation.Transactional;


import java.time.LocalDate;
import java.util.List;
import java.util.UUID;



@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "livro")
@Transactional
public class Livro {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id_livro;
    private String titulo;
    private LocalDate ano;
    private Tipo tipo_livro;

    @ManyToMany(mappedBy = "livros", cascade = CascadeType.ALL)
    @JsonBackReference
    private List<Usuario> usuarios;

    public Livro(String titulo, LocalDate ano, Tipo tipo_livro, List<Usuario> usuarios) {
        this.titulo = titulo;
        this.ano = ano;
        this.tipo_livro = tipo_livro;
        this.usuarios = usuarios;
    }
}
