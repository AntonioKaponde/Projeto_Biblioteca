package com.br.Ishare.model;

import com.br.Ishare.dtos.EmprestimoDto;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "usuario")
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id_usuario;
    private String nome_usuario;
    private String email_usuario;
    private Integer idade_usuario;
    private String morada_usuario;

    @OneToMany(mappedBy = "usuario",orphanRemoval = true,cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Emprestimo> emprestimos;

    @ManyToMany
    @JsonManagedReference
    @JoinTable(
            name = "usuario_livro",
            joinColumns = @JoinColumn(name = "fk_usuario",referencedColumnName = "id_usuario"),
            inverseJoinColumns = @JoinColumn(name = "fk_livro",referencedColumnName = "id_livro")
    )
    private List<Livro> livros;


}
