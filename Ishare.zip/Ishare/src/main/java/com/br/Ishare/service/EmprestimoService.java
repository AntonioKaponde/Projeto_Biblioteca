package com.br.Ishare.service;

import com.br.Ishare.dtos.EmprestimoDto;
import com.br.Ishare.dtos.UsuarioDto;
import com.br.Ishare.model.Emprestimo;
import com.br.Ishare.model.Usuario;
import com.br.Ishare.repository.EmprestimoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class EmprestimoService {
    @Autowired
    private EmprestimoRepository repository;

    public Emprestimo criar_emprestimo(EmprestimoDto emprestimoDto){
        var emprestimo = new Emprestimo();
        emprestimo.data_emprestimos();
        emprestimo.setData_devolucao(emprestimoDto.data_devolucao());

        return  repository.save(emprestimo);
    }


    public List<Emprestimo> listar_emprestimos(){
        return  this.repository.findAll();
    }


    public Emprestimo get_emprestimoId(UUID id_emprestimo){
        if(id_emprestimo != null){
            return repository.findById(id_emprestimo).get();
        }else {
            return null;
        }
    }


    public void remove_emprestimo(UUID id_usuario){
        this.repository.deleteById(id_usuario);
    }
}
