package com.br.Ishare.service;

import com.br.Ishare.dtos.LivroDto;
import com.br.Ishare.enums.Tipo;
import com.br.Ishare.model.Emprestimo;
import com.br.Ishare.model.Livro;
import com.br.Ishare.repository.EmprestimoRepository;
import com.br.Ishare.repository.LivroRepository;
import org.antlr.v4.runtime.misc.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class LivroService {
    @Autowired
    private LivroRepository repository;

    public Livro criar_livro(LivroDto livroDto){
        var livro = new Livro();

        livro.setTitulo(livroDto.titulo());
        livro.setAno(livroDto.ano());
        livro.setTipo_livro(Tipo.CIENTIFICO);

        return repository.save(livro);
    }

    public List<Livro> listar_livros(){
         return  this.repository.findAll();
    }

    public Livro get_livroId(UUID id_livro){
        if(id_livro != null){
        return repository.findById(id_livro).get();
    }else {
            return null;
        }
    }

    public void remove_livro(UUID id_livro){
        this.repository.deleteById(id_livro);
    }
}
