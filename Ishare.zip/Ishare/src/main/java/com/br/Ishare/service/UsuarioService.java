package com.br.Ishare.service;

import com.br.Ishare.dtos.EmprestimoDto;
import com.br.Ishare.dtos.LivroDto;
import com.br.Ishare.dtos.UsuarioDto;
import com.br.Ishare.enums.Tipo;
import com.br.Ishare.model.Emprestimo;
import com.br.Ishare.model.Livro;
import com.br.Ishare.model.Usuario;
import com.br.Ishare.repository.EmprestimoRepository;
import com.br.Ishare.repository.LivroRepository;
import com.br.Ishare.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
public class UsuarioService {
    @Autowired
    private UsuarioRepository repository;
    @Autowired
    private EmprestimoRepository emprestimoRepository;

    @Autowired
    private LivroRepository livroRepository;

    public Usuario criar_usuario(UsuarioDto usuarioDto){
        var usuario = new Usuario();

        usuario.setNome_usuario(usuarioDto.nome_usuario());
        usuario.setEmail_usuario(usuarioDto.email_usuario());
        usuario.setIdade_usuario(usuarioDto.idade_usuario());
        usuario.setMorada_usuario(usuarioDto.morada_usuario());

        return repository.save(usuario);

    }

    public List<Usuario> listar_usuarios(){
        return  this.repository.findAll();
    }


    public Usuario get_usuarioId(UUID id_usuario){
        if(id_usuario != null){
            return repository.findById(id_usuario).get();
        }else {
            return null;
        }
    }


    public void remove_usuario(UUID id_usuario){
        this.repository.deleteById(id_usuario);
    }

    public void criar_usuarioEmprestimo(EmprestimoDto emprestimoDto, String id_usuario) {
        var usuario = repository.findById(UUID.fromString(id_usuario))
                .orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND));
        var emprestimo = new Emprestimo();
        emprestimo.data_emprestimos();
        emprestimo.setData_devolucao(emprestimoDto.data_devolucao());
        emprestimo.setUsuario(usuario);

        emprestimoRepository.save(emprestimo);

    }


    public Usuario criarUsuarioLivro(String id_usuario, String id_livro) {
        List<Livro> livros = null;

        var usuario = repository.findById(UUID.fromString(id_usuario)).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        var livro = livroRepository.findById(UUID.fromString(id_livro));

        if (livro.isPresent()) {
            livros = usuario.getLivros();
            livros.add(livro.get());
            usuario.setLivros(livros);
            return repository.save(usuario);
        }else {

            return usuario;
        }


    }
}
